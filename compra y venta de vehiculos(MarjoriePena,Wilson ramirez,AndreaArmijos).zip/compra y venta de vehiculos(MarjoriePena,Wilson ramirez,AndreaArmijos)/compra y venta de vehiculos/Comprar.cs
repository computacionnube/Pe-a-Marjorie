﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace compra_y_venta_de_vehiculos
{
    public partial class Comprar : Form
    {
        public Comprar()
        {
            InitializeComponent();
        }
        
        string nombre, direccion, telefono, email, compañia_seguros, agente_seguros, telefono_seguros, institucion_financiera, telefono_institucion_financiera;
        double costo1 = 21.900, costo2 = 10.700, costo3 = 17.800, costo4 = 10.900;
        
        private void limpiar()
        {
            textnombre.Text = "";
            textdireccion.Text = "";
            texttelefono.Text = "";
            textemail.Text = "";
            textcompañia_seguros.Text = "";
            textagente_seguros.Text = "";
            texttelefono_seguros.Text = "";
            textinstitucion_financiera.Text = "";
            texttel_fin.Text = "";
            listresultados.Items.Clear();                
        }

        private void btnaceptar_Click(object sender, EventArgs e)
        {           
            nombre = textnombre.Text;
            direccion = textdireccion.Text;
            telefono = texttelefono.Text;
            email = textemail.Text;
            compañia_seguros = textcompañia_seguros.Text;
            agente_seguros = textagente_seguros.Text;
            telefono_seguros = texttelefono_seguros.Text;
            institucion_financiera = textinstitucion_financiera.Text;
            telefono_institucion_financiera = texttel_fin.Text;
            listresultados.Items.Add(textnombre.Text + "," + textdireccion.Text + "," + texttelefono.Text + "," + textemail.Text + "," + textemail.Text + "," + textcompañia_seguros.Text + "," + textagente_seguros.Text + "," + texttelefono_seguros.Text + "," + textinstitucion_financiera.Text + "," + texttel_fin.Text + "," + textsubtotal.Text + "," + textIVA.Text + "," + textvalor_total.Text + "," + textefectivo.Text + "," + textcambio);
        }

        private void btnnuevo_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        private void btnnuevacompra_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textnombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void textdireccion_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void textcompañia_seguros_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void textagente_seguros_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void textinstitucion_financiera_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void texttelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            } 
        }

        private void texttelefono_seguros_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            } 
        }

        private void texttel_fin_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            } 
        }


        private void textsubtotal_TextChanged(object sender, EventArgs e)
        {
            
        }
        double IVA = 0.12, calculo = 0, valor_total = 0;
        double efectivo = 0, cambio = 0;
        private void btncalcular_Click(object sender, EventArgs e)
        {
            if (textsubtotal.Text == label19.Text)
            {
                calculo = costo1 * IVA;
                textIVA.Text = calculo.ToString();
                valor_total = costo1 + calculo;
                textvalor_total.Text = valor_total.ToString(); 
            }
            if (textsubtotal.Text == label20.Text)
            {
                calculo = costo2 * IVA;
                textIVA.Text = calculo.ToString();
                valor_total = costo2 + calculo;
                textvalor_total.Text = valor_total.ToString();
            }
            if (textsubtotal.Text == label21.Text)
            {
                calculo = costo3 * IVA;
                textIVA.Text = calculo.ToString();
                valor_total = costo3 + calculo;
                textvalor_total.Text = valor_total.ToString();
            }
            if (textsubtotal.Text == label22.Text)
            {
                calculo = costo4 * IVA;
                textIVA.Text = calculo.ToString();
                valor_total = costo4 + calculo;
                textvalor_total.Text = valor_total.ToString();
            }


        }

        private void Comprar_Load(object sender, EventArgs e)
        {

        }

        private void textcambio_TextChanged(object sender, EventArgs e)
        {

        }

        private void textefectivo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textvalor_total_TextChanged(object sender, EventArgs e)
        {

        }

        private void textIVA_TextChanged(object sender, EventArgs e)
        {

        }

        private void texttel_fin_TextChanged(object sender, EventArgs e)
        {

        }

        private void textinstitucion_financiera_TextChanged(object sender, EventArgs e)
        {

        }

        private void texttelefono_seguros_TextChanged(object sender, EventArgs e)
        {

        }

        private void textagente_seguros_TextChanged(object sender, EventArgs e)
        {

        }

        private void textcompañia_seguros_TextChanged(object sender, EventArgs e)
        {

        }

        private void textemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void texttelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void textdireccion_TextChanged(object sender, EventArgs e)
        {

        }

        private void textnombre_TextChanged(object sender, EventArgs e)
        {

        }

       


      

      

       
    }
}
