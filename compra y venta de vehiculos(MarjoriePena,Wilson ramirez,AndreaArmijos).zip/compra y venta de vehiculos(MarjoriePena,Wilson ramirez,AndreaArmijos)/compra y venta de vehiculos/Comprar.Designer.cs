﻿namespace compra_y_venta_de_vehiculos
{
    partial class Comprar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Comprar));
            this.textnombre = new System.Windows.Forms.TextBox();
            this.texttelefono_seguros = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.texttel_fin = new System.Windows.Forms.TextBox();
            this.textcompañia_seguros = new System.Windows.Forms.TextBox();
            this.textemail = new System.Windows.Forms.TextBox();
            this.texttelefono = new System.Windows.Forms.TextBox();
            this.textdireccion = new System.Windows.Forms.TextBox();
            this.textagente_seguros = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textinstitucion_financiera = new System.Windows.Forms.TextBox();
            this.listresultados = new System.Windows.Forms.ListBox();
            this.btnnuevo = new System.Windows.Forms.Button();
            this.btnaceptar = new System.Windows.Forms.Button();
            this.btnnuevacompra = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textsubtotal = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textefectivo = new System.Windows.Forms.TextBox();
            this.textvalor_total = new System.Windows.Forms.TextBox();
            this.textIVA = new System.Windows.Forms.TextBox();
            this.textcambio = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textnombre
            // 
            this.textnombre.Location = new System.Drawing.Point(65, 15);
            this.textnombre.Name = "textnombre";
            this.textnombre.Size = new System.Drawing.Size(248, 20);
            this.textnombre.TabIndex = 16;
            this.textnombre.TextChanged += new System.EventHandler(this.textnombre_TextChanged);
            this.textnombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textnombre_KeyPress);
            // 
            // texttelefono_seguros
            // 
            this.texttelefono_seguros.Location = new System.Drawing.Point(173, 186);
            this.texttelefono_seguros.Name = "texttelefono_seguros";
            this.texttelefono_seguros.Size = new System.Drawing.Size(140, 20);
            this.texttelefono_seguros.TabIndex = 17;
            this.texttelefono_seguros.TextChanged += new System.EventHandler(this.texttelefono_seguros_TextChanged);
            this.texttelefono_seguros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttelefono_seguros_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Nombre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Teléfono:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Dirección:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Compañia de Seguros:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Agente de Seguros:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Teléfono de la CIA de Seguros:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 244);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Teléfono Institución Financiera:";
            // 
            // texttel_fin
            // 
            this.texttel_fin.Location = new System.Drawing.Point(173, 241);
            this.texttel_fin.Name = "texttel_fin";
            this.texttel_fin.Size = new System.Drawing.Size(140, 20);
            this.texttel_fin.TabIndex = 26;
            this.texttel_fin.TextChanged += new System.EventHandler(this.texttel_fin_TextChanged);
            this.texttel_fin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttel_fin_KeyPress);
            // 
            // textcompañia_seguros
            // 
            this.textcompañia_seguros.Location = new System.Drawing.Point(135, 130);
            this.textcompañia_seguros.Name = "textcompañia_seguros";
            this.textcompañia_seguros.Size = new System.Drawing.Size(178, 20);
            this.textcompañia_seguros.TabIndex = 27;
            this.textcompañia_seguros.TextChanged += new System.EventHandler(this.textcompañia_seguros_TextChanged);
            this.textcompañia_seguros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textcompañia_seguros_KeyPress);
            // 
            // textemail
            // 
            this.textemail.Location = new System.Drawing.Point(53, 104);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(260, 20);
            this.textemail.TabIndex = 28;
            this.textemail.TextChanged += new System.EventHandler(this.textemail_TextChanged);
            // 
            // texttelefono
            // 
            this.texttelefono.Location = new System.Drawing.Point(65, 69);
            this.texttelefono.Name = "texttelefono";
            this.texttelefono.Size = new System.Drawing.Size(248, 20);
            this.texttelefono.TabIndex = 29;
            this.texttelefono.TextChanged += new System.EventHandler(this.texttelefono_TextChanged);
            this.texttelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttelefono_KeyPress);
            // 
            // textdireccion
            // 
            this.textdireccion.Location = new System.Drawing.Point(65, 43);
            this.textdireccion.Name = "textdireccion";
            this.textdireccion.Size = new System.Drawing.Size(248, 20);
            this.textdireccion.TabIndex = 30;
            this.textdireccion.TextChanged += new System.EventHandler(this.textdireccion_TextChanged);
            this.textdireccion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdireccion_KeyPress);
            // 
            // textagente_seguros
            // 
            this.textagente_seguros.Location = new System.Drawing.Point(119, 156);
            this.textagente_seguros.Name = "textagente_seguros";
            this.textagente_seguros.Size = new System.Drawing.Size(194, 20);
            this.textagente_seguros.TabIndex = 32;
            this.textagente_seguros.TextChanged += new System.EventHandler(this.textagente_seguros_TextChanged);
            this.textagente_seguros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textagente_seguros_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 34;
            this.label9.Text = "Institución Financiera:";
            // 
            // textinstitucion_financiera
            // 
            this.textinstitucion_financiera.Location = new System.Drawing.Point(128, 215);
            this.textinstitucion_financiera.Name = "textinstitucion_financiera";
            this.textinstitucion_financiera.Size = new System.Drawing.Size(185, 20);
            this.textinstitucion_financiera.TabIndex = 35;
            this.textinstitucion_financiera.TextChanged += new System.EventHandler(this.textinstitucion_financiera_TextChanged);
            this.textinstitucion_financiera.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textinstitucion_financiera_KeyPress);
            // 
            // listresultados
            // 
            this.listresultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listresultados.FormattingEnabled = true;
            this.listresultados.ItemHeight = 24;
            this.listresultados.Location = new System.Drawing.Point(12, 402);
            this.listresultados.Name = "listresultados";
            this.listresultados.Size = new System.Drawing.Size(817, 100);
            this.listresultados.TabIndex = 36;
            // 
            // btnnuevo
            // 
            this.btnnuevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnnuevo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnuevo.Location = new System.Drawing.Point(333, 59);
            this.btnnuevo.Name = "btnnuevo";
            this.btnnuevo.Size = new System.Drawing.Size(121, 42);
            this.btnnuevo.TabIndex = 37;
            this.btnnuevo.Text = "Nuevo";
            this.btnnuevo.UseVisualStyleBackColor = false;
            this.btnnuevo.Click += new System.EventHandler(this.btnnuevo_Click);
            // 
            // btnaceptar
            // 
            this.btnaceptar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnaceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaceptar.Location = new System.Drawing.Point(333, 219);
            this.btnaceptar.Name = "btnaceptar";
            this.btnaceptar.Size = new System.Drawing.Size(121, 42);
            this.btnaceptar.TabIndex = 38;
            this.btnaceptar.Text = "Aceptar";
            this.btnaceptar.UseVisualStyleBackColor = false;
            this.btnaceptar.Click += new System.EventHandler(this.btnaceptar_Click);
            // 
            // btnnuevacompra
            // 
            this.btnnuevacompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnnuevacompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnuevacompra.Location = new System.Drawing.Point(333, 104);
            this.btnnuevacompra.Name = "btnnuevacompra";
            this.btnnuevacompra.Size = new System.Drawing.Size(121, 61);
            this.btnnuevacompra.TabIndex = 39;
            this.btnnuevacompra.Text = "Nueva Compra";
            this.btnnuevacompra.UseVisualStyleBackColor = false;
            this.btnnuevacompra.Click += new System.EventHandler(this.btnnuevacompra_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(583, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 40;
            this.pictureBox1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 271);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 41;
            this.label10.Text = "Subtotal:";
            // 
            // textsubtotal
            // 
            this.textsubtotal.Location = new System.Drawing.Point(65, 267);
            this.textsubtotal.Name = "textsubtotal";
            this.textsubtotal.Size = new System.Drawing.Size(157, 20);
            this.textsubtotal.TabIndex = 42;
            this.textsubtotal.Text = "$ 21.900";
            this.textsubtotal.TextChanged += new System.EventHandler(this.textsubtotal_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 43;
            this.label11.Text = "IVA 12%:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 325);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 44;
            this.label12.Text = "Valor Total:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 376);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 13);
            this.label13.TabIndex = 45;
            this.label13.Text = "Cambio:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 351);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 46;
            this.label14.Text = "Efectivo:";
            // 
            // textefectivo
            // 
            this.textefectivo.Location = new System.Drawing.Point(71, 348);
            this.textefectivo.Name = "textefectivo";
            this.textefectivo.Size = new System.Drawing.Size(151, 20);
            this.textefectivo.TabIndex = 47;
            this.textefectivo.TextChanged += new System.EventHandler(this.textefectivo_TextChanged);
            // 
            // textvalor_total
            // 
            this.textvalor_total.Location = new System.Drawing.Point(82, 322);
            this.textvalor_total.Name = "textvalor_total";
            this.textvalor_total.Size = new System.Drawing.Size(140, 20);
            this.textvalor_total.TabIndex = 48;
            this.textvalor_total.TextChanged += new System.EventHandler(this.textvalor_total_TextChanged);
            // 
            // textIVA
            // 
            this.textIVA.Location = new System.Drawing.Point(65, 293);
            this.textIVA.Name = "textIVA";
            this.textIVA.Size = new System.Drawing.Size(157, 20);
            this.textIVA.TabIndex = 49;
            this.textIVA.TextChanged += new System.EventHandler(this.textIVA_TextChanged);
            // 
            // textcambio
            // 
            this.textcambio.Location = new System.Drawing.Point(71, 373);
            this.textcambio.Name = "textcambio";
            this.textcambio.Size = new System.Drawing.Size(151, 20);
            this.textcambio.TabIndex = 50;
            this.textcambio.TextChanged += new System.EventHandler(this.textcambio_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Aqua;
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Location = new System.Drawing.Point(254, 271);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 118);
            this.panel1.TabIndex = 51;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(107, 93);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 13);
            this.label22.TabIndex = 55;
            this.label22.Text = "$10.900";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 93);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(107, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Subtotal Vehículo 4: ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(107, 67);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 13);
            this.label21.TabIndex = 54;
            this.label21.Text = "$17.800";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 67);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(107, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "Subtotal Vehículo 3: ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(107, 38);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 13);
            this.label20.TabIndex = 53;
            this.label20.Text = "$10.700";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Subtotal Vehículo 2: ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(107, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 52;
            this.label19.Text = "$21.900";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Subtotal Vehículo 1: ";
            // 
            // btncalcular
            // 
            this.btncalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcular.Location = new System.Drawing.Point(333, 172);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(121, 42);
            this.btncalcular.TabIndex = 52;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = false;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // Comprar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(849, 514);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textcambio);
            this.Controls.Add(this.textIVA);
            this.Controls.Add(this.textvalor_total);
            this.Controls.Add(this.textefectivo);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textsubtotal);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnnuevacompra);
            this.Controls.Add(this.btnaceptar);
            this.Controls.Add(this.btnnuevo);
            this.Controls.Add(this.listresultados);
            this.Controls.Add(this.textinstitucion_financiera);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textagente_seguros);
            this.Controls.Add(this.textdireccion);
            this.Controls.Add(this.texttelefono);
            this.Controls.Add(this.textemail);
            this.Controls.Add(this.textcompañia_seguros);
            this.Controls.Add(this.texttel_fin);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.texttelefono_seguros);
            this.Controls.Add(this.textnombre);
            this.Name = "Comprar";
            this.Text = "Comprar";
            this.Load += new System.EventHandler(this.Comprar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textnombre;
        private System.Windows.Forms.TextBox texttelefono_seguros;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox texttel_fin;
        private System.Windows.Forms.TextBox textcompañia_seguros;
        private System.Windows.Forms.TextBox textemail;
        private System.Windows.Forms.TextBox texttelefono;
        private System.Windows.Forms.TextBox textdireccion;
        private System.Windows.Forms.TextBox textagente_seguros;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textinstitucion_financiera;
        private System.Windows.Forms.ListBox listresultados;
        private System.Windows.Forms.Button btnnuevo;
        private System.Windows.Forms.Button btnaceptar;
        private System.Windows.Forms.Button btnnuevacompra;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textsubtotal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textefectivo;
        private System.Windows.Forms.TextBox textvalor_total;
        private System.Windows.Forms.TextBox textIVA;
        private System.Windows.Forms.TextBox textcambio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btncalcular;
    }
}