﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace compra_y_venta_de_vehiculos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void btncomprar1_Click(object sender, EventArgs e)
        {
            Comprar comp = new Comprar();
            comp.ShowDialog();
            
            
            
        }
        private void btncomprar2_Click(object sender, EventArgs e)
        {
            Comprar comp = new Comprar();
            comp.ShowDialog();
        }

        private void btncomprar3_Click(object sender, EventArgs e)
        {
            Comprar comp = new Comprar();
            comp.ShowDialog();
        }

        private void btncomprar4_Click(object sender, EventArgs e)
        {
            Comprar comp = new Comprar();
            comp.ShowDialog();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
